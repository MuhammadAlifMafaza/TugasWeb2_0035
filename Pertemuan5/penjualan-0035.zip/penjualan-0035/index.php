<?php
require_once 'config/database.php';
require_once 'models/Produk.php';
require_once 'controllers/ProdukController.php';

$model = new Produk($db);
$controller = new ProdukController($model);

$controller->listProduk();  // example route

?>
