<?php
class Produk {
    private $db;

    public function __construct($database) {
        $this->db = $database;
    }

    public function getAllProduk() {
        $query = $this->db->query("SELECT * FROM barang");
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    // Other CRUD methods (e.g., addProduk, updateProduk, deleteProduk)
}
?>
