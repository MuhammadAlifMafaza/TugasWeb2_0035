<?php
class ProdukController {
    private $model;

    public function __construct($model) {
        $this->model = $model;
    }

    public function listProduk() {
        $Produk = $this->model->getAllProduk();
        include 'views/Produk.php';
    }

    // Additional actions like adding or editing Produk
}
?>
