<!DOCTYPE html>
<html>
<head>
    <title>Produk List</title>
</head>
<body>
    <h1>Daftar Produk</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Stok</th>
        </tr>
        <?php foreach ($produkList as $produk): ?>
        <tr>
            <td><?= $produk['id'] ?></td>
            <td><?= $produk['nama_produk'] ?></td>
            <td><?= $produk['harga'] ?></td>
            <td><?= $produk['stok'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
