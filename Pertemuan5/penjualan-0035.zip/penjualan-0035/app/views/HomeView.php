<?php
include 'header.php';
?>

<h1>Selamat Datang di Sistem Penjualan</h1>
<p>Silakan pilih menu di atas untuk mengelola data.</p>

<?php
include 'footer.php';
?>